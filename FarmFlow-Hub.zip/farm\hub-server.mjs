/**
 * Farm Hub — main control for up to 50 Chrome workers.
 * Serves UI + API on http://127.0.0.1:8787
 *
 *   node hub-server.mjs
 */
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import { assignJobs, parsePromptsText } from "./assign.mjs";
import {
  workerStatus,
  workerStart,
  workerStop,
  workerLogs,
  workerSetRef,
  openProject,
  ensureProject
} from "./worker-client.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.FARM_HUB_PORT || 8787);
const BASE_PORT = Number(process.env.FARM_BASE_PORT || 9301);
const MAX_WORKERS = Number(process.env.FARM_MAX_WORKERS || 50);
const STATE_FILE = path.join(__dirname, "workers-state.json");
const RUN_FILE = path.join(__dirname, "run-state.json");

let run = loadRun();

function loadRun() {
  try {
    return JSON.parse(fs.readFileSync(RUN_FILE, "utf8"));
  } catch (_) {
    return {
      running: false,
      startedAt: null,
      windowsUsed: 0,
      total: 0,
      done: 0,
      failed: 0,
      assignment: null,
      workers: {},
      lastError: ""
    };
  }
}

function saveRun() {
  fs.writeFileSync(RUN_FILE, JSON.stringify(run, null, 2));
}

function sanitizeGenName(raw) {
  const s = String(raw || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 40);
  return s || "farm";
}

function listOutputFiles(outDir) {
  const files = [];
  function walk(dir, rel = "") {
    if (!fs.existsSync(dir)) return;
    for (const name of fs.readdirSync(dir)) {
      const full = path.join(dir, name);
      const relPath = rel ? `${rel}/${name}` : name;
      let st;
      try {
        st = fs.statSync(full);
      } catch (_) {
        continue;
      }
      if (st.isDirectory()) {
        if (name.startsWith(".")) continue;
        walk(full, relPath);
      } else if (/\.(png|jpe?g|webp)$/i.test(name)) {
        files.push({
          name: relPath.replace(/\\/g, "/"),
          bytes: st.size,
          mtime: st.mtime.toISOString(),
          url: `/outputs/${relPath.split("/").map(encodeURIComponent).join("/")}`
        });
      }
    }
  }
  walk(outDir);
  return files.sort((a, b) => (a.name < b.name ? -1 : 1));
}

function clearOutputFiles(outDir) {
  let removed = 0;
  function walk(dir) {
    if (!fs.existsSync(dir)) return;
    for (const name of fs.readdirSync(dir)) {
      const full = path.join(dir, name);
      let st;
      try {
        st = fs.statSync(full);
      } catch (_) {
        continue;
      }
      if (st.isDirectory()) {
        walk(full);
        try {
          fs.rmdirSync(full);
        } catch (_) {}
      } else if (/\.(png|jpe?g|webp)$/i.test(name) || name.startsWith("_temp")) {
        try {
          fs.unlinkSync(full);
          removed += 1;
        } catch (_) {}
      }
    }
  }
  walk(outDir);
  return removed;
}

function readWorkersState() {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
  } catch (_) {
    return { workers: [], basePort: BASE_PORT };
  }
}

function workerMeta(id) {
  const st = readWorkersState();
  const w = (st.workers || []).find((x) => x.id === id);
  const port = w?.port || BASE_PORT + id - 1;
  const profile =
    w?.profile ||
    path.join(__dirname, "workers", `w${String(id).padStart(2, "0")}`);
  return { id, port, profile, projectUrl: w?.projectUrl || "" };
}

function saveWorkerProject(id, projectUrl) {
  const st = readWorkersState();
  st.workers = st.workers || [];
  let w = st.workers.find((x) => x.id === id);
  if (!w) {
    w = {
      id,
      port: BASE_PORT + id - 1,
      profile: path.join(__dirname, "workers", `w${String(id).padStart(2, "0")}`)
    };
    st.workers.push(w);
  }
  w.projectUrl = projectUrl;
  w.projectAt = new Date().toISOString();
  st.updatedAt = new Date().toISOString();
  fs.writeFileSync(STATE_FILE, JSON.stringify(st, null, 2));
  return w;
}

async function probeWorkers(max = MAX_WORKERS) {
  const st = readWorkersState();
  const knownIds = (st.workers || []).map((w) => w.id);
  const hi = knownIds.length ? Math.max(...knownIds) : 10;
  const limit = Math.min(max, Math.max(hi, 10));
  const out = [];
  for (let id = 1; id <= limit; id++) {
    const meta = workerMeta(id);
    const alive = await new Promise((resolve) => {
      const req = http.get(
        { host: "127.0.0.1", port: meta.port, path: "/json/version", timeout: 400 },
        (res) => {
          res.resume();
          resolve(res.statusCode === 200);
        }
      );
      req.on("error", () => resolve(false));
      req.on("timeout", () => {
        req.destroy();
        resolve(false);
      });
    });
    if (!alive) {
      out.push({
        id,
        port: meta.port,
        online: false,
        projectUrl: meta.projectUrl || ""
      });
      continue;
    }
    const wst = await workerStatus(meta.port, meta.profile);
    const logsTail = String(wst?.storage?.logsTail || wst?.logs?.text || "");
    const lines = logsTail.split("\n").filter(Boolean);
    const lastLine = lines.length ? lines[lines.length - 1] : "";
    const tabUrl = wst?.tab?.url || "";
    const liveProject = /\/project\//i.test(tabUrl) ? tabUrl : "";
    out.push({
      id,
      port: meta.port,
      online: true,
      automating: !!wst?.storage?.isAutomating,
      lastError: wst?.storage?.lastError || "",
      jobIndex: wst?.storage?.jobIndex || 0,
      statsCompleted: wst?.storage?.statsCompleted || 0,
      tab: wst?.tab || null,
      projectUrl: liveProject || meta.projectUrl || "",
      ok: wst?.ok !== false,
      error: wst?.error || "",
      lastLine,
      logsTail
    });
  }
  return out;
}

function json(res, code, body) {
  const data = JSON.stringify(body);
  res.writeHead(code, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => {
      try {
        const raw = Buffer.concat(chunks).toString("utf8");
        resolve(raw ? JSON.parse(raw) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on("error", reject);
  });
}

async function stopAll(ids) {
  for (const id of ids) {
    const meta = workerMeta(id);
    try {
      await workerStop(meta.port, meta.profile);
    } catch (_) {}
  }
}

async function runFarm(payload) {
  if (run.running) throw new Error("Already running");
  const prompts = Array.isArray(payload.prompts)
    ? payload.prompts
    : parsePromptsText(payload.promptsText || "");
  if (!prompts.length) throw new Error("No prompts");

  const genName = sanitizeGenName(payload.genName || payload.generationName);
  const maxWindows = Math.max(1, Math.min(MAX_WORKERS, Number(payload.maxWindows) || 10));
  const probed = await probeWorkers(MAX_WORKERS);
  const online = probed.filter((w) => w.online);
  if (!online.length) throw new Error("No online workers. Launch workers first.");

  const windowsUsed = Math.min(maxWindows, prompts.length, online.length);
  const { queues } = assignJobs(prompts, windowsUsed);
  const selected = online.slice(0, windowsUsed);

  run = {
    running: true,
    startedAt: new Date().toISOString(),
    genName,
    windowsUsed,
    total: prompts.length,
    done: 0,
    failed: 0,
    assignment: queues.map((q, i) => ({
      workerId: selected[i].id,
      files: q.map((_, ji) => `${genName}_w${selected[i].id}_${String(ji + 1).padStart(2, "0")}`),
      jobs: q.map((j) => ({ jobIndex: j.jobIndex, prompt: j.prompt.slice(0, 80) }))
    })),
    workers: Object.fromEntries(
      selected.map((w, i) => [
        w.id,
        {
          status: "starting",
          jobs: queues[i].map((j) => j.jobIndex),
          current: null,
          done: 0,
          failed: 0,
          lastError: ""
        }
      ])
    ),
    lastError: ""
  };
  saveRun();

  const settings = {
    aspectRatio: payload.aspectRatio || "16:9",
    batchSize: payload.batchSize || "x1",
    model: payload.model || "Nano Banana 2",
    restDelay: String(payload.restDelay || "3")
  };
  const refImage = payload.refImage || null;
  const sharedProjectUrl = String(payload.projectUrl || "").trim();
  const autoEnsure = payload.ensureProject !== false;

  // Fire workers in parallel — each uses OWN projectUrl
  const tasks = selected.map(async (w, i) => {
    const jobs = queues[i];
    const meta = workerMeta(w.id);
    run.workers[w.id].status = "running";
    saveRun();
    try {
      // Always set or clear ref explicitly (cloned profiles keep old banana ref otherwise)
      await workerSetRef(meta.port, meta.profile, refImage || null);
      const prompts = jobs.map((j) => j.prompt);
      const jobIndexes = jobs.map((j) => Number(j.jobIndex));

      let urlToOpen =
        meta.projectUrl ||
        w.projectUrl ||
        (/\/project\//i.test(w.tab?.url || "") ? w.tab.url : "") ||
        sharedProjectUrl ||
        "";

      if (autoEnsure || !urlToOpen) {
        const ensured = await ensureProject(meta.port, {
          preferredUrl: urlToOpen || sharedProjectUrl,
          createIfMissing: true
        });
        if (!ensured?.ok) {
          throw new Error(ensured?.error || "Ensure project failed");
        }
        urlToOpen = ensured.url;
        saveWorkerProject(w.id, urlToOpen);
      } else {
        const opened = await openProject(meta.port, urlToOpen);
        if (!opened?.ok) {
          const ensured = await ensureProject(meta.port, {
            preferredUrl: sharedProjectUrl,
            createIfMissing: true
          });
          if (!ensured?.ok) {
            throw new Error(opened?.error || ensured?.error || "Open project failed");
          }
          urlToOpen = ensured.url;
          saveWorkerProject(w.id, urlToOpen);
        } else {
          saveWorkerProject(w.id, opened.url);
          urlToOpen = opened.url;
        }
      }
      // Plain JSON clone — avoid any non-enumerable loss across CDP evaluate
      const startPayload = JSON.parse(
        JSON.stringify({
          jobs: jobs.map((j) => ({
            prompt: j.prompt,
            jobIndex: Number(j.jobIndex),
            index: Number(j.jobIndex)
          })),
          prompts,
          jobIndexes,
          startJobIndex: jobIndexes[0] || 1,
          genName,
          workerId: w.id,
          ...settings,
          refImage: refImage || null,
          clearRef: !refImage
        })
      );
      fs.writeFileSync(
        path.join(__dirname, `debug-start-w${w.id}.json`),
        JSON.stringify({ workerId: w.id, genName, jobs, payload: startPayload }, null, 2)
      );
      const res = await workerStart(meta.port, meta.profile, startPayload);
      if (!res?.success) {
        throw new Error(res?.error || res?.message || "start failed");
      }

      // Poll until idle
      const deadline = Date.now() + Math.max(180_000, jobs.length * 240_000);
      let lastDone = -1;
      while (Date.now() < deadline) {
        if (!run.running) break;
        const st = await workerStatus(meta.port, meta.profile);
        const automating = !!st?.storage?.isAutomating;
        const completed = Number(st?.storage?.statsCompleted || 0);
        const failed = Number(st?.storage?.statsFailed || 0);
        const jobIndex = Number(st?.storage?.jobIndex || 0);
        run.workers[w.id].current = jobIndex || null;
        run.workers[w.id].lastError = st?.storage?.lastError || "";
        if (completed !== lastDone) {
          lastDone = completed;
          saveRun();
        }
        if (!automating) {
          run.workers[w.id].done = jobs.length;
          run.workers[w.id].failed = failed;
          run.workers[w.id].status = st?.storage?.lastError ? "error" : "done";
          run.done += jobs.length;
          if (st?.storage?.lastError) run.failed += 1;
          saveRun();
          return;
        }
        await new Promise((r) => setTimeout(r, 2500));
      }
      run.workers[w.id].status = "timeout";
      run.failed += 1;
      saveRun();
    } catch (e) {
      run.workers[w.id].status = "error";
      run.workers[w.id].lastError = e.message || String(e);
      run.failed += 1;
      run.lastError = e.message || String(e);
      saveRun();
    }
  });

  Promise.all(tasks).then(() => {
    run.running = false;
    run.finishedAt = new Date().toISOString();
    saveRun();
  });

  return {
    ok: true,
    genName,
    windowsUsed,
    total: prompts.length,
    assignment: run.assignment
  };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || "/", `http://127.0.0.1:${PORT}`);

  try {
    if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/hub")) {
      const html = fs.readFileSync(path.join(__dirname, "hub.html"), "utf8");
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(html);
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/status") {
      const workers = await probeWorkers(MAX_WORKERS);
      json(res, 200, { run, workers, basePort: BASE_PORT, maxWorkers: MAX_WORKERS });
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/launch") {
      const body = await readBody(req);
      const count = Math.max(1, Math.min(MAX_WORKERS, Number(body.count) || 4));
      const project = body.projectUrl || "";
      const child = spawn(
        process.execPath,
        [
          path.join(__dirname, "launch-workers.mjs"),
          "--count",
          String(count),
          ...(project ? ["--project", project] : [])
        ],
        { cwd: __dirname, stdio: "inherit" }
      );
      await new Promise((resolve) => child.on("exit", resolve));
      json(res, 200, { ok: true, count, state: readWorkersState() });
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/ensure-projects") {
      const body = await readBody(req);
      const createIfMissing = body.createIfMissing !== false;
      const shared = String(body.projectUrl || "").trim();
      const probed = await probeWorkers(MAX_WORKERS);
      const online = probed.filter((w) => w.online);
      const ids = (body.workerIds || online.map((w) => w.id)).slice(0, MAX_WORKERS);
      const results = [];
      for (const id of ids) {
        const meta = workerMeta(id);
        if (!online.some((w) => w.id === id)) {
          results.push({ id, ok: false, error: "offline" });
          continue;
        }
        try {
          const r = await ensureProject(meta.port, {
            preferredUrl: meta.projectUrl || shared,
            createIfMissing
          });
          if (r.ok && r.url) saveWorkerProject(id, r.url);
          results.push({ id, ...r });
        } catch (e) {
          results.push({ id, ok: false, error: e.message || String(e) });
        }
      }
      json(res, 200, {
        results,
        ok: results.filter((r) => r.ok).length,
        needLogin: results.filter((r) => r.needLogin).map((r) => r.id)
      });
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/open-project") {
      const body = await readBody(req);
      const projectUrl = body.projectUrl;
      const probed = await probeWorkers(MAX_WORKERS);
      const onlineIds = probed.filter((w) => w.online).map((w) => w.id);
      const ids = (body.workerIds || onlineIds).slice(0, MAX_WORKERS);
      const results = [];
      for (const id of ids) {
        const meta = workerMeta(id);
        try {
          // Per-account: ensure own project (shared URL only as preferred hint)
          const r = await ensureProject(meta.port, {
            preferredUrl: projectUrl || meta.projectUrl,
            createIfMissing: true
          });
          if (r.ok && r.url) saveWorkerProject(id, r.url);
          results.push({ id, ...r });
        } catch (e) {
          results.push({ id, ok: false, error: e.message });
        }
      }
      json(res, 200, { results });
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/preview-assign") {
      const body = await readBody(req);
      const prompts = Array.isArray(body.prompts)
        ? body.prompts
        : parsePromptsText(body.promptsText || "");
      const genName = sanitizeGenName(body.genName || body.generationName);
      const maxWindows = Math.max(1, Math.min(MAX_WORKERS, Number(body.maxWindows) || 10));
      const online = (await probeWorkers(MAX_WORKERS)).filter((w) => w.online).length;
      const windowsUsed = Math.min(maxWindows, prompts.length, Math.max(1, online || maxWindows));
      const { queues } = assignJobs(prompts, windowsUsed);
      json(res, 200, {
        total: prompts.length,
        windowsUsed,
        online,
        genName,
        assignment: queues.map((q, i) => ({
          window: i + 1,
          files: q.map((_, ji) => `${genName}_w${i + 1}_${String(ji + 1).padStart(2, "0")}.png`),
          jobs: q.map((j) => j.jobIndex)
        }))
      });
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/start") {
      const body = await readBody(req);
      const result = await runFarm(body);
      json(res, 200, result);
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/stop") {
      run.running = false;
      const ids = Object.keys(run.workers || {}).map(Number);
      await stopAll(ids.length ? ids : [1, 2, 3, 4]);
      saveRun();
      json(res, 200, { ok: true });
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/logs") {
      const id = Number(url.searchParams.get("worker") || 1);
      const meta = workerMeta(id);
      try {
        const logs = await workerLogs(meta.port, meta.profile, 80);
        json(res, 200, logs);
      } catch (e) {
        json(res, 200, { text: e.message, success: false });
      }
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/clear-outputs") {
      const outDir = path.join(__dirname, "out", "FarmFlow");
      fs.mkdirSync(outDir, { recursive: true });
      const removed = clearOutputFiles(outDir);
      json(res, 200, { ok: true, removed, dir: outDir });
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/outputs") {
      const outDir = path.join(__dirname, "out", "FarmFlow");
      fs.mkdirSync(outDir, { recursive: true });
      const files = listOutputFiles(outDir);
      json(res, 200, {
        dir: outDir,
        count: files.length,
        files
      });
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/open-outputs") {
      const outDir = path.join(__dirname, "out", "FarmFlow");
      fs.mkdirSync(outDir, { recursive: true });
      spawn("explorer.exe", [outDir], { detached: true, stdio: "ignore" }).unref();
      json(res, 200, { ok: true, dir: outDir });
      return;
    }

    if (req.method === "GET" && url.pathname.startsWith("/outputs/")) {
      const rel = decodeURIComponent(url.pathname.slice("/outputs/".length));
      if (!rel || rel.includes("..") || path.isAbsolute(rel)) {
        json(res, 400, { error: "bad name" });
        return;
      }
      const outDir = path.join(__dirname, "out", "FarmFlow");
      const full = path.resolve(outDir, rel);
      if (!full.startsWith(path.resolve(outDir) + path.sep) && full !== path.resolve(outDir)) {
        json(res, 400, { error: "bad name" });
        return;
      }
      if (!fs.existsSync(full) || !fs.statSync(full).isFile()) {
        json(res, 404, { error: "missing" });
        return;
      }
      const ext = path.extname(full).toLowerCase();
      const type =
        ext === ".png"
          ? "image/png"
          : ext === ".webp"
            ? "image/webp"
            : "image/jpeg";
      res.writeHead(200, { "Content-Type": type, "Cache-Control": "no-store" });
      fs.createReadStream(full).pipe(res);
      return;
    }

    json(res, 404, { error: "not found" });
  } catch (e) {
    json(res, 500, { error: e.message || String(e) });
  }
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`[hub] http://127.0.0.1:${PORT}`);
  console.log(`[hub] Workers CDP base :${BASE_PORT} (W1…W${MAX_WORKERS})`);
});

process.on("uncaughtException", (e) => {
  console.error("[hub] uncaught", e);
});
process.on("unhandledRejection", (e) => {
  console.error("[hub] rejection", e);
});
