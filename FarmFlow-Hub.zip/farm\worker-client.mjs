/**
 * Worker CDP client — talk to Farm Flow on a given port.
 */
import fs from "node:fs";
import path from "node:path";
import { chromium } from "playwright-core";

const KNOWN_EXT = "elidfapcjaamaoggpdogaenmjcibabla";

function readExtId(profileDir) {
  try {
    const prefPath = path.join(profileDir, "Default", "Preferences");
    const j = JSON.parse(fs.readFileSync(prefPath, "utf8"));
    const settings = j?.extensions?.settings || {};
    for (const [id, meta] of Object.entries(settings)) {
      const p = String(meta?.path || "").replace(/\\/g, "/").toLowerCase();
      if (p.endsWith("/extension") || p.includes("/farm/extension")) return id;
      if (meta?.manifest?.name === "Farm Flow") return id;
    }
  } catch (_) {}
  return process.env.FARM_EXT_ID || KNOWN_EXT;
}

async function messageViaPanel(browser, extId, message) {
  const ctx = browser.contexts()[0];
  const page = await ctx.newPage();
  try {
    await page.goto(`chrome-extension://${extId}/panel.html`, {
      waitUntil: "domcontentloaded",
      timeout: 12000
    });
    // Pass as JSON string — structured clone via CDP sometimes drops fields
    const raw = JSON.stringify(message);
    return await page.evaluate(async (json) => {
      const msg = JSON.parse(json);
      return chrome.runtime.sendMessage(msg);
    }, raw);
  } finally {
    await page.close().catch(() => {});
  }
}

export async function withWorker(port, profileDir, fn) {
  const browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`);
  try {
    const extId = readExtId(profileDir);
    return await fn({
      browser,
      extId,
      call: (action, payload = {}) =>
        messageViaPanel(browser, extId, { action, ...payload })
    });
  } finally {
    await browser.close().catch(() => {});
  }
}

export async function workerStatus(port, profileDir) {
  try {
    return await withWorker(port, profileDir, async ({ extId, call }) => {
      const state = await call("AGENT_GET_STATE");
      return { ok: true, port, extId, ...state };
    });
  } catch (e) {
    return { ok: false, port, error: e.message || String(e) };
  }
}

export async function workerStart(port, profileDir, payload) {
  return withWorker(port, profileDir, async ({ browser, extId }) => {
    const ctx = browser.contexts()[0];
    const page = await ctx.newPage();
    try {
      await page.goto(`chrome-extension://${extId}/panel.html`, {
        waitUntil: "domcontentloaded",
        timeout: 12000
      });
      const raw = JSON.stringify(payload);
      // Arm storage FIRST with authoritative indexes, then start
      return await page.evaluate(async (json) => {
        const p = JSON.parse(json);
        const prompts = (p.prompts || []).map((s) => String(s || "").trim()).filter(Boolean);
        const jobIndexes = (p.jobIndexes || [])
          .map((n) => Number(n))
          .filter((n) => Number.isFinite(n) && n > 0);
        if (!prompts.length) return { success: false, error: "No prompts" };
        const indexes =
          jobIndexes.length === prompts.length
            ? jobIndexes
            : prompts.map((_, i) => Number(p.startJobIndex || 1) + i);
        const PROMPT_SEP = "\n@@@FARM_NEXT@@@\n";
        await new Promise((resolve) => {
          chrome.storage.local.set(
            {
              flow_prompts_text: prompts.join(PROMPT_SEP),
              flow_job_index_queue: JSON.stringify(indexes),
              flow_aspect_ratio: p.aspectRatio || "16:9",
              flow_batch_size: p.batchSize || "x1",
              flow_model: p.model || "Nano Banana 2",
              flow_rest_delay: String(p.restDelay || "3"),
              flow_ref_image: p.refImage || null,
              flow_last_error: "",
              flow_stats_completed: 0,
              flow_stats_failed: 0,
              flow_is_paused: false,
              flow_gen_name: String(p.genName || p.generationName || "farm")
                .trim()
                .toLowerCase()
                .replace(/[^a-z0-9_-]+/g, "_")
                .replace(/^_+|_+$/g, "")
                .slice(0, 40) || "farm",
              flow_worker_id: Math.max(1, Number(p.workerId || p.windowId || 1) || 1),
              flow_download_seq: 0
            },
            resolve
          );
        });
        return chrome.runtime.sendMessage({
          action: "AGENT_START",
          prompts,
          jobIndexes: indexes,
          startJobIndex: indexes[0],
          jobs: prompts.map((prompt, i) => ({
            prompt,
            jobIndex: indexes[i],
            index: indexes[i]
          })),
          aspectRatio: p.aspectRatio || "16:9",
          batchSize: p.batchSize || "x1",
          model: p.model || "Nano Banana 2",
          restDelay: String(p.restDelay || "3"),
          refImage: p.refImage || null,
          clearRef: !p.refImage,
          genName: String(p.genName || p.generationName || "farm"),
          workerId: Math.max(1, Number(p.workerId || p.windowId || 1) || 1),
          preArmed: true
        });
      }, raw);
    } finally {
      await page.close().catch(() => {});
    }
  });
}

export async function workerStop(port, profileDir) {
  return withWorker(port, profileDir, ({ call }) => call("AGENT_STOP"));
}

export async function workerLogs(port, profileDir, tail = 40) {
  return withWorker(port, profileDir, ({ call }) =>
    call("AGENT_GET_LOGS", { tail })
  );
}

export async function workerSetRef(port, profileDir, refImage) {
  return withWorker(port, profileDir, ({ call }) =>
    call("AGENT_SET_REF", { refImage })
  );
}

export function findFlowPage(browser) {
  for (const ctx of browser.contexts()) {
    for (const page of ctx.pages()) {
      const u = page.url() || "";
      if (u.includes("flow.google.com") || u.includes("labs.google")) {
        return page;
      }
    }
  }
  return null;
}

export async function openProject(port, url) {
  const browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`);
  try {
    const ctx = browser.contexts()[0];
    let page = findFlowPage(browser);
    if (!page) page = await ctx.newPage();
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
    await page.waitForTimeout(2000);
    const finalUrl = page.url();
    if (!/\/project\//i.test(finalUrl)) {
      // Retry once — Flow sometimes bounce to /about or /
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
      await page.waitForTimeout(2500);
    }
    const check = page.url();
    if (!/\/project\//i.test(check)) {
      return { ok: false, error: `Not on project after open: ${check}`, url: check };
    }
    return { ok: true, url: check };
  } finally {
    await browser.close().catch(() => {});
  }
}

async function clickMatching(page, patterns) {
  return page.evaluate((pats) => {
    const re = pats.map((p) => new RegExp(p, "i"));
    const els = Array.from(
      document.querySelectorAll("button, a, [role='button'], [role='link']")
    ).filter((el) => {
      const r = el.getBoundingClientRect();
      return r.width > 8 && r.height > 8;
    });
    for (const el of els) {
      const blob = `${el.innerText || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("href") || ""}`;
      if (re.some((r) => r.test(blob))) {
        el.click();
        return {
          ok: true,
          text: (el.innerText || el.getAttribute("aria-label") || "")
            .replace(/\s+/g, " ")
            .trim()
            .slice(0, 80)
        };
      }
    }
    return { ok: false };
  }, patterns);
}

async function waitForProjectUrl(page, timeoutMs = 20000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const u = page.url();
    if (/\/project\/[a-f0-9-]{8,}/i.test(u)) return u;
    await page.waitForTimeout(400);
  }
  return page.url();
}

/**
 * Ensure this worker is on ITS OWN Flow project.
 * - reuse current /project/ tab
 * - or open preferredUrl if it works for this account
 * - or leave /about via CTA → home → New project
 * - or open first existing project card
 */
export async function ensureProject(port, opts = {}) {
  const preferredUrl = String(opts.preferredUrl || "").trim();
  const createIfMissing = opts.createIfMissing !== false;
  const browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`);
  try {
    const ctx = browser.contexts()[0];
    let page = findFlowPage(browser);
    if (!page) page = await ctx.newPage();

    // Already on a project belonging to this session
    if (/\/project\/[a-f0-9-]{8,}/i.test(page.url() || "")) {
      return { ok: true, url: page.url(), method: "already-open" };
    }

    // Try preferred URL (only works if this Google account owns it)
    if (preferredUrl && /\/project\//i.test(preferredUrl)) {
      await page.goto(preferredUrl, { waitUntil: "domcontentloaded", timeout: 60000 });
      await page.waitForTimeout(2000);
      let u = await waitForProjectUrl(page, 8000);
      if (/\/project\/[a-f0-9-]{8,}/i.test(u)) {
        return { ok: true, url: u, method: "preferred" };
      }
    }

    // Marketing /about → enter app
    await page.goto("https://flow.google.com/", {
      waitUntil: "domcontentloaded",
      timeout: 60000
    });
    await page.waitForTimeout(2000);
    if (/\/about/i.test(page.url())) {
      const cta = await clickMatching(page, [
        "create with google flow",
        "try in google flow",
        "^create$",
        "get started",
        "open flow"
      ]);
      await page.waitForTimeout(2500);
      if (/\/about/i.test(page.url())) {
        await page.goto("https://flow.google.com/", {
          waitUntil: "domcontentloaded",
          timeout: 60000
        });
        await page.waitForTimeout(2000);
      }
      if (!cta.ok && /\/about|accounts\.google/i.test(page.url())) {
        return {
          ok: false,
          error: `Need Google login / Flow access first (${page.url()})`,
          url: page.url(),
          needLogin: true
        };
      }
    }

    // Still about or login wall
    if (/accounts\.google\.com|ServiceLogin/i.test(page.url())) {
      return {
        ok: false,
        error: `Login required: ${page.url()}`,
        url: page.url(),
        needLogin: true
      };
    }

    let u = page.url();
    if (/\/project\/[a-f0-9-]{8,}/i.test(u)) {
      return { ok: true, url: u, method: "home-redirect" };
    }

    if (createIfMissing) {
      const neu = await clickMatching(page, ["new\\s*project", "add\\s*new\\s*project"]);
      if (neu.ok) {
        u = await waitForProjectUrl(page, 20000);
        if (/\/project\/[a-f0-9-]{8,}/i.test(u)) {
          return { ok: true, url: u, method: "created", clicked: neu.text };
        }
      }
    }

    // Fallback: open first existing project card
    const opened = await page.evaluate(() => {
      const a = Array.from(document.querySelectorAll('a[aria-label="Open project"], a[href*="/project/"]'))
        .find((el) => {
          const href = el.getAttribute("href") || el.href || "";
          return /\/project\/[a-f0-9-]{8,}/i.test(href);
        });
      if (!a) return { ok: false };
      const href = a.href || a.getAttribute("href");
      a.click();
      return { ok: true, href };
    });
    if (opened.ok) {
      u = await waitForProjectUrl(page, 15000);
      if (/\/project\/[a-f0-9-]{8,}/i.test(u)) {
        return { ok: true, url: u, method: "existing", clicked: opened.href };
      }
    }

    return {
      ok: false,
      error: `Could not open/create project (at ${page.url()}). Login in this window, then Ensure again.`,
      url: page.url(),
      needLogin: /about|accounts\.google/i.test(page.url())
    };
  } finally {
    await browser.close().catch(() => {});
  }
}
