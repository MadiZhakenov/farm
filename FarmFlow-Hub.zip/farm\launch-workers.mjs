/**
 * Launch up to 50 Chrome workers with Farm Flow loaded.
 * Each worker: own profile + CDP port (9301+).
 *
 * Usage:
 *   node launch-workers.mjs [--count 4] [--from 1] [--project URL]
 */
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import http from "node:http";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const EXT = path.resolve(ROOT, "extension");
const WORKERS_DIR = path.join(__dirname, "workers");
const TEMPLATE = path.resolve(ROOT, "profile"); // optional; created empty if missing
const BASE_PORT = Number(process.env.FARM_BASE_PORT || 9301);
const MAX = Number(process.env.FARM_MAX_WORKERS || 50);

const CHROME_CANDIDATES = [
  process.env.CHROME_PATH,
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
  "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
].filter(Boolean);

function findChrome() {
  for (const p of CHROME_CANDIDATES) {
    if (fs.existsSync(p)) return p;
  }
  throw new Error("Chrome not found. Set CHROME_PATH.");
}

function parseArgs(argv) {
  const args = { count: 4, from: 1, project: process.env.FARM_PROJECT_URL || "" };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--count") args.count = Number(argv[++i] || 4);
    else if (a === "--from") args.from = Number(argv[++i] || 1);
    else if (a === "--project") args.project = argv[++i] || "";
  }
  args.count = Math.max(1, Math.min(MAX, args.count));
  args.from = Math.max(1, Math.min(MAX, args.from));
  return args;
}

function cdpAlive(port) {
  return new Promise((resolve) => {
    const req = http.get(
      { host: "127.0.0.1", port, path: "/json/version", timeout: 600 },
      (res) => {
        res.resume();
        resolve(res.statusCode === 200);
      }
    );
    req.on("error", () => resolve(false));
    req.on("timeout", () => {
      req.destroy();
      resolve(false);
    });
  });
}

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
    if (ent.name === "SingletonLock" || ent.name === "SingletonCookie" || ent.name === "SingletonSocket") {
      continue;
    }
    const s = path.join(src, ent.name);
    const d = path.join(dest, ent.name);
    if (ent.isDirectory()) copyDir(s, d);
    else {
      try {
        fs.copyFileSync(s, d);
      } catch (_) {}
    }
  }
}

function ensureProfile(id) {
  const dir = path.join(WORKERS_DIR, `w${String(id).padStart(2, "0")}`);
  const marker = path.join(dir, "Default", "Preferences");
  if (!fs.existsSync(marker) && fs.existsSync(path.join(TEMPLATE, "Default", "Preferences"))) {
    console.log(`[farm] cloning session → worker ${id}`);
    copyDir(TEMPLATE, dir);
  } else {
    fs.mkdirSync(dir, { recursive: true });
  }
  // Shared download folder so prompt-01…NN land in one place
  const outDir = path.join(__dirname, "out");
  fs.mkdirSync(outDir, { recursive: true });
  try {
    const prefPath = path.join(dir, "Default", "Preferences");
    if (fs.existsSync(prefPath)) {
      const j = JSON.parse(fs.readFileSync(prefPath, "utf8"));
      j.download = j.download || {};
      j.download.default_directory = outDir;
      j.download.prompt_for_download = false;
      j.savefile = j.savefile || {};
      j.savefile.default_directory = outDir;
      fs.writeFileSync(prefPath, JSON.stringify(j));
    }
  } catch (e) {
    console.warn(`[farm] download path warn W${id}:`, e.message);
  }
  return dir;
}

async function launchOne(id, chrome, startUrl) {
  const port = BASE_PORT + id - 1;
  if (await cdpAlive(port)) {
    console.log(`[farm] W${id} already up :${port}`);
    return { id, port, profile: path.join(WORKERS_DIR, `w${String(id).padStart(2, "0")}`), reused: true };
  }
  const profile = ensureProfile(id);
  const args = [
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${profile}`,
    `--disable-extensions-except=${EXT}`,
    `--load-extension=${EXT}`,
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-features=ChromeWhatsNewUI",
    `--window-size=1100,750`,
    `--window-position=${40 + ((id - 1) % 5) * 40},${40 + Math.floor((id - 1) / 5) * 40}`
  ];
  if (startUrl) args.push(startUrl);
  else args.push("https://flow.google.com/");

  const child = spawn(chrome, args, { detached: true, stdio: "ignore" });
  child.unref();

  for (let i = 0; i < 50; i++) {
    await new Promise((r) => setTimeout(r, 400));
    if (await cdpAlive(port)) break;
  }
  if (!(await cdpAlive(port))) throw new Error(`W${id} CDP :${port} failed`);
  console.log(`[farm] W${id} ready :${port} · ${profile}`);
  return { id, port, profile, reused: false };
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const chrome = findChrome();
  fs.mkdirSync(WORKERS_DIR, { recursive: true });
  const workers = [];
  for (let i = 0; i < args.count; i++) {
    const id = args.from + i;
    if (id > MAX) break;
    workers.push(await launchOne(id, chrome, args.project));
  }
  const statePath = path.join(__dirname, "workers-state.json");
  fs.writeFileSync(
    statePath,
    JSON.stringify(
      {
        basePort: BASE_PORT,
        extension: EXT,
        updatedAt: new Date().toISOString(),
        workers
      },
      null,
      2
    )
  );
  console.log(`[farm] ${workers.length} worker(s). State → ${statePath}`);
  console.log(`[farm] Log into Google/Flow in each new window if needed, open a project, then use the Hub.`);
}

main().catch((e) => {
  console.error("[farm]", e.message || e);
  process.exit(1);
});
