/**
 * Round-robin job assignment across windows.
 * Downloads named per gen + worker: {gen}_w{N}_NN
 */
export function assignJobs(prompts, maxWindows) {
  const list = (prompts || []).map((p) => String(p || "").trim()).filter(Boolean);
  const n = list.length;
  const cap = Math.max(1, Math.min(50, maxWindows | 0));
  const windowsUsed = Math.max(0, Math.min(cap, n));
  const queues = Array.from({ length: windowsUsed }, () => []);
  for (let i = 0; i < n; i++) {
    const jobIndex = i + 1;
    const w = i % windowsUsed;
    queues[w].push({ prompt: list[i], jobIndex });
  }
  return { prompts: list, windowsUsed, queues };
}

export function parsePromptsText(raw) {
  const text = String(raw || "");
  if (text.includes("@@@FARM_NEXT@@@")) {
    return text
      .split("@@@FARM_NEXT@@@")
      .map((b) => b.replace(/^\n+|\n+$/g, "").trim())
      .filter((b) => b && !b.startsWith("# ERR:"));
  }
  const blocks = text
    .split(/\n\s*\n/)
    .map((b) => b.trim())
    .filter((b) => b && !b.startsWith("# ERR:"));
  return blocks.length ? blocks : text.trim() ? [text.trim()] : [];
}
