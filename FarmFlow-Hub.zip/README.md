# Farm Flow + Farm Hub

Chrome extension for bulk image generation on [Google Flow](https://flow.google.com) + local Hub to run many windows (different Google accounts), each with its own project.

## What's inside

| Path | What |
|------|------|
| `extension/` | Farm Flow MV3 extension (load unpacked) |
| `farm/` | Farm Hub server + worker launcher |
| `launch.mjs` / `agent.mjs` | Optional single-window lab (CDP) |

**Not included (on purpose):** Chrome profiles, logins, downloads, `node_modules`.

## Requirements

- Windows (Hub opens Explorer; Chrome/Edge)
- Node.js 18+
- Google Chrome

## Setup

```powershell
cd FarmFlow-Hub
npm install
```

## 1) Extension only (one browser)

1. Chrome → `chrome://extensions` → Developer mode → **Load unpacked** → select `extension/`
2. Open a Flow **project** tab (`https://flow.google.com/project/…`)
3. Click the Farm Flow icon → side panel → paste prompts → Start

## 2) Farm Hub (many windows)

```powershell
npm run hub
```

Open **http://127.0.0.1:8787**

Typical flow for fresh accounts:

1. Set **Окон** (e.g. 4) → **Launch windows**
2. In each Chrome window: sign into **its** Google account
3. **Ensure projects** — creates/opens a project per window and remembers the URL
4. Enter **название генерации** (e.g. `fruits`) + prompts
5. **Start farm**

Files land in `farm/out/FarmFlow/{name}/{name}_wN_NN.jpg`  
Example: `fruits/fruits_w1_01.jpg`, `fruits_w2_01.jpg`

## Notes

- Unofficial automation — Flow UI changes can break selectors.
- Prefer secondary Google accounts; respect rate limits / ToS.
- Yellow “debugging this browser” banner is normal (CDP).
- Max workers default: 50 (RAM-heavy).

## Version

Extension `1.8.1` · Hub with per-worker projects + generation naming.
